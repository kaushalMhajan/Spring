package example.hibernate.entity;

public class Movie {
	
	private Integer movieId;
	private String title;
	private int duration;
	private String genre;
	
	public Movie() {
		super();
	}
	
	
	public Movie(Integer movieId, String title, int duration, String genre) {
		super();
		this.movieId = movieId;
		this.title = title;
		this.duration = duration;
		this.genre = genre;
	}
	
	
	public Integer getMovieId() {
		return movieId;
	}
	public void setMovieId(Integer movieId) {
		this.movieId = movieId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getGenre() {
		return genre;
	}
	public void setGenre(String genre) {
		this.genre = genre;
	}
	
	
	

}
