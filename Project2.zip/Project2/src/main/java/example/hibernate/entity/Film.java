package example.hibernate.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;

@Entity
@Table(name = "Film_table")
public class Film {
	
	@jakarta.persistence.Id
	@Column(name="f_id")
	private Integer Id;
	
	@Column(name="fname")
	private String movieName;
	
	
	@Column(name="fduration")
	private int duration;

	public Film(Integer id, String movieName, int duration) {
		super();
		Id = id;
		this.movieName = movieName;
		this.duration = duration;
	}

	public Integer getId() {
		return Id;
	}

	public void setId(Integer id) {
		Id = id;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public int getDuration() {
		return duration;
	}

	public void setDuration(int duration) {
		this.duration = duration;
	}
	
}
