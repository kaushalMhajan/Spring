package project2.main1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import example.hibernate.entity.Film;
import example.hibernate.utitlies.ProgramaticConfiguration;

public class Film_main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory factory = ProgramaticConfiguration.getSession();
		Session sessionObj = factory.openSession();
		
		Film fm = new Film(102,"Avenger",30);
		
		Transaction tx = sessionObj.beginTransaction();
		sessionObj.persist(fm);
		tx.commit();
		sessionObj.close();
		factory.close();
		
	}

}
