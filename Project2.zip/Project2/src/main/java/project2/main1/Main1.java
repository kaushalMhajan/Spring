package project2.main1;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import example.hibernate.entity.Movie;

public class Main1 {

	public static void main(String[] args) {
		
		
		//step 1: Configuration : connection with database;
		Configuration conf = new Configuration();
		conf = conf.configure();
		
		//step 2:Create session factory to open session;
		SessionFactory factory = conf.buildSessionFactory();
		Session sessionObj = factory.openSession();
		
		
		Movie m1 = new Movie(102,"pushpa",30,"action");
		
		//step 3:Begin the transaction using Transaction;
		Transaction tx = sessionObj.beginTransaction();
		
		sessionObj.persist(m1);
		
		tx.commit();
		
		//step 4: Close the connection
		sessionObj.close();
		factory.close();
		
	}

}
